MESSAGE_DELIMITER = "|"


def encode_message(msg_type, *fields):
    if fields:
        return f"{msg_type}{MESSAGE_DELIMITER}" + MESSAGE_DELIMITER.join(map(str, fields))
    return msg_type


def decode_message(message):
    parts = message.strip().split(MESSAGE_DELIMITER)

    if len(parts) < 1:
        raise ValueError("Malformed message")

    return parts


VALID_MESSAGE_TYPES = {
    "DISCOVER",
    "HANDSHAKE",
    "HS_ACK",
    "MSG",
    "MSG_ACK",
    "CLOSE",
    "ERROR"
}